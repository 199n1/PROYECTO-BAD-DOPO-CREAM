package logic;

import domain.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Motor del juego 
 */
public class GameEngine implements Serializable {
    private static final long serialVersionUID = 1L;

    private Nivel nivelActual;
    private int numeroNivel;
    private int puntajeTotal;
    private boolean pausado;
    private boolean juegoTerminado;
    private boolean nivelCompletado;

    private String modalidad;  // "Player" o "PvsP"
    private Helado helado;
    private Helado helado2;  // Solo existe en modo PvsP
    private String colorHelado;

    private ManejadorTiempo temporizador;

    private List<TipoObstaculoMapa> obstaculosPorNivel;
    private List<TipoFruta[]> frutasPorNivel;
    private List<TipoEnemigo> enemigoPorNivel;

    public GameEngine(String modalidad, String colorHelado) throws GameException {
        this.modalidad = modalidad;
        this.colorHelado = colorHelado;
        this.puntajeTotal = 0;
        this.numeroNivel = 1;
        this.pausado = false;
        this.juegoTerminado = false;
        this.nivelCompletado = false;
        this.temporizador = new ManejadorTiempo();
        
        this.obstaculosPorNivel = new ArrayList<>();
        this.frutasPorNivel = new ArrayList<>();
        this.enemigoPorNivel = new ArrayList<>();
        
        configuracionPorDefecto();
        iniciarNivel(1);
    }

    private void configuracionPorDefecto() {
        setConfiguracionNivel(0, TipoObstaculoMapa.HIELO, TipoFruta.UVA, TipoFruta.BANANO, TipoEnemigo.TROLL);
        setConfiguracionNivel(1, TipoObstaculoMapa.BALDOSA_CALIENTE, TipoFruta.CEREZA, TipoFruta.PINA, TipoEnemigo.MACETA);
        setConfiguracionNivel(2, TipoObstaculoMapa.FOGATA, TipoFruta.PINA, TipoFruta.CACTUS, TipoEnemigo.CALAMAR);
    }

    public void setConfiguracionNivel(int nivelIndex, TipoObstaculoMapa obstaculo, 
                                     TipoFruta fruta1, TipoFruta fruta2, TipoEnemigo enemigo) {
        ensureSize(nivelIndex + 1);
        obstaculosPorNivel.set(nivelIndex, obstaculo);
        frutasPorNivel.set(nivelIndex, new TipoFruta[]{fruta1, fruta2});
        enemigoPorNivel.set(nivelIndex, enemigo);
    }

    private void ensureSize(int size) {
        while (obstaculosPorNivel.size() < size) {
            obstaculosPorNivel.add(TipoObstaculoMapa.HIELO);
        }
        while (frutasPorNivel.size() < size) {
            frutasPorNivel.add(new TipoFruta[]{TipoFruta.UVA, TipoFruta.BANANO});
        }
        while (enemigoPorNivel.size() < size) {
            enemigoPorNivel.add(TipoEnemigo.TROLL);
        }
    }

    public void iniciarNivel(int numeroNivel) throws GameException {
        this.numeroNivel = numeroNivel;
        this.nivelCompletado = false;

        ensureSize(numeroNivel);
        TipoObstaculoMapa obstaculo = obstaculosPorNivel.get(numeroNivel - 1);
        TipoFruta[] frutas = frutasPorNivel.get(numeroNivel - 1);
        TipoEnemigo enemigo = enemigoPorNivel.get(numeroNivel - 1);

        String sabor = colorHelado != null ? colorHelado : "Vainilla";
        helado = new Helado(3, 7, null, sabor);

        if (modalidad.equals("PvsP")) {
            helado2 = new Helado(11, 7, null, "Chocolate");
        } else {
            helado2 = null;
        }

        nivelActual = new Nivel(numeroNivel, helado, obstaculo, frutas[0], frutas[1], enemigo);
        
        helado.setMapa(nivelActual.getMapa());
        if (helado2 != null) {
            helado2.setMapa(nivelActual.getMapa());
        }

        temporizador.reiniciar();
        pausado = false;
    }

    /**
     * Actualiza el estado del juego cada frame
     */
    public void actualizar() {
        if (pausado || juegoTerminado || nivelActual == null) return;

        temporizador.actualizar();
        nivelActual.actualizar();

        // Verificar colisiones y reglas para jugador 1
        verificarReglas(helado);
        
        // Verificar colisiones y reglas para jugador 2 (si existe)
        if (helado2 != null) {
            verificarReglas(helado2);
        }

        // Verificar si el nivel se completó
        if (nivelActual.nivelCompletado()) {
            nivelCompletado = true;
        }

        // Verificar si se acabó el tiempo
        if (temporizador.tiempoAgotado()) {
            nivelCompletado = true;
        }
    }

    /**
     * Verifica las reglas del juego para un helado
     */
    private void verificarReglas(Helado h) {
        if (h == null || !h.isVivo()) return;

        // Colisión con enemigos
        if (nivelActual.verificarColisionEnemigos(h)) {
            h.morir();
            juegoTerminado = true;
            return;
        }

        // Colisión con fogatas
        if (nivelActual.verificarColisionFogatas(h)) {
            h.morir();
            juegoTerminado = true;
            return;
        }

        // Colisión con frutas
        Fruta f = nivelActual.verificarColisionFrutas(h);
        if (f != null && f.isActiva()) {
            if (!(f instanceof Cactus) || ((Cactus) f).puedeSerRecolectado()) {
                f.recolectar();
                puntajeTotal = puntajeTotal + f.getPuntos();
            }
        }
    }

    // ==================== CONTROL DEL JUEGO ====================

    public void moverHelado(String direccion) {
        if (helado != null && helado.isVivo()) {
            helado.mover(direccion);
        }
    }

    public void accionBloque() {
        if (helado != null && helado.isVivo()) {
            helado.crearBloques();
        }
    }

    public void siguienteNivel() throws GameException {
        int siguiente = numeroNivel + 1;
        if (siguiente > 3) {
            juegoTerminado = true;
        } else {
            iniciarNivel(siguiente);
        }
    }

    public void reiniciarJuego() throws GameException {
        puntajeTotal = 0;
        juegoTerminado = false;
        nivelCompletado = false;
        iniciarNivel(1);
    }

    // ==================== GETTERS ====================

    public Nivel getNivel() { return nivelActual; }
    public Nivel getNivelActual() { return nivelActual; }
    public int getNumeroNivel() { return numeroNivel; }
    public int getPuntaje() { return puntajeTotal; }
    public int getPuntajeTotal() { return puntajeTotal; }
    public int getVidasRestantes() { return 0; }
    public boolean isPausado() { return pausado; }
    public boolean isJuegoTerminado() { return juegoTerminado; }
    public boolean isGameOver() { return juegoTerminado; }
    public boolean isNivelCompletado() { return nivelCompletado; }
    public Helado getHelado() { return helado; }
    public Helado getHelado1() { return helado; }
    public Helado getHelado2() { return helado2; }
    public ManejadorTiempo getTemporizador() { return temporizador; }
    public String getModalidad() { return modalidad; }
    
    public int getFrutasRecolectadas() {
        if (nivelActual == null) return 0;
        return nivelActual.getFrutasRecolectadas();
    }
    
    public String getTiempoRestante() {
        return temporizador.getTiempoFormateado();
    }
    
    public boolean juegoCompletado() {
        return numeroNivel >= 3 && nivelCompletado;
    }

    public void pausar() { pausado = true; }
    public void reanudar() { pausado = false; }
    public void terminar() { juegoTerminado = true; }
}