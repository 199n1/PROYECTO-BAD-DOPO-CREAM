package logic;

/**
 * Clase que maneja el temporizador del juego
 * Cada nivel tiene un máximo de 3 minutos (180 segundos)
 */
public class ManejadorTiempo {

    private int framesPorSegundo = 60;
    private int tiempoMaximoSegundos = 180;
    private int framesTranscurridos;
    private boolean pausado;
    private boolean tiempoAgotado;

    public ManejadorTiempo() {
        this.framesTranscurridos = 0;
        this.pausado = false;
        this.tiempoAgotado = false;
    }

    public void actualizar() {
        if (pausado || tiempoAgotado) {
            return;
        }

        framesTranscurridos++;

        if (getSegundosRestantes() <= 0) {
            tiempoAgotado = true;
        }
    }

    public int getSegundosTranscurridos() {
        return framesTranscurridos / framesPorSegundo;
    }

    public int getSegundosRestantes() {
        int transcurridos = getSegundosTranscurridos();
        int restantes = tiempoMaximoSegundos - transcurridos;
        return Math.max(0, restantes);
    }

    public String getTiempoFormateado() {
        int segundosRestantes = getSegundosRestantes();
        int minutos = segundosRestantes / 60;
        int segundos = segundosRestantes % 60;
        return String.format("%d:%02d", minutos, segundos);
    }

    public boolean tiempoAgotado() {
        return tiempoAgotado;
    }

    public void pausar() {
        pausado = true;
    }

    public void reanudar() {
        pausado = false;
    }

    public boolean estaPausado() {
        return pausado;
    }

    public void reiniciar() {
        framesTranscurridos = 0;
        pausado = false;
        tiempoAgotado = false;
    }

    public void setTiempoMaximo(int segundos) {
        this.tiempoMaximoSegundos = segundos;
    }

    public double getPorcentajeTiempo() {
        return (double) getSegundosRestantes() / tiempoMaximoSegundos;
    }

    public boolean tiempoEnAlerta() {
        return getSegundosRestantes() < 30 && getSegundosRestantes() > 0;
    }
}