package presentation;

import domain.*;
import logic.GameEngine;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Pantalla para configurar los 3 niveles del juego
 */
public class PantallaConfiguracionNiveles extends JFrame {
    
    private String modalidad;
    private String saborHelado;
    private int nivelActual;
    private Image fondoImagen;
    
    private TipoObstaculoMapa[] obstaculosSeleccionados;
    private TipoFruta[][] frutasSeleccionadas;
    private TipoEnemigo[] enemigosSeleccionados;
    
    private JLabel lblNivel;
    private JComboBox<TipoObstaculoMapa> cmbObstaculo;
    private JComboBox<TipoFruta> cmbFruta1;
    private JComboBox<TipoFruta> cmbFruta2;
    private JComboBox<TipoEnemigo> cmbEnemigo;
    private JButton btnAnterior;
    private JButton btnSiguiente;
    private JButton btnJugar;
    
    public PantallaConfiguracionNiveles(String modalidad, String saborHelado) {
        this.modalidad = modalidad;
        this.saborHelado = saborHelado;
        this.nivelActual = 1;
        
        this.obstaculosSeleccionados = new TipoObstaculoMapa[3];
        this.frutasSeleccionadas = new TipoFruta[3][2];
        this.enemigosSeleccionados = new TipoEnemigo[3];
        
        cargarFondo();
        inicializarConfiguracionDefecto();
        configurarVentana();
        inicializarComponentes();
        actualizarVista();
    }
    
    private void cargarFondo() {
        try {
            java.net.URL imgURL = getClass().getResource("/resources/imagenes/fondo_niveles.png");
            if (imgURL != null) {
                fondoImagen = new ImageIcon(imgURL).getImage();
            }
        } catch (Exception e) {
            System.err.println("Error al cargar fondo: " + e.getMessage());
        }
    }
    
    private void inicializarConfiguracionDefecto() {
        obstaculosSeleccionados[0] = TipoObstaculoMapa.HIELO;
        frutasSeleccionadas[0][0] = TipoFruta.UVA;
        frutasSeleccionadas[0][1] = TipoFruta.BANANO;
        enemigosSeleccionados[0] = TipoEnemigo.TROLL;
        
        obstaculosSeleccionados[1] = TipoObstaculoMapa.BALDOSA_CALIENTE;
        frutasSeleccionadas[1][0] = TipoFruta.CEREZA;
        frutasSeleccionadas[1][1] = TipoFruta.PINA;
        enemigosSeleccionados[1] = TipoEnemigo.MACETA;
        
        obstaculosSeleccionados[2] = TipoObstaculoMapa.FOGATA;
        frutasSeleccionadas[2][0] = TipoFruta.PINA;
        frutasSeleccionadas[2][1] = TipoFruta.CACTUS;
        enemigosSeleccionados[2] = TipoEnemigo.CALAMAR;
    }
    
    private void configurarVentana() {
        setTitle("Configurar Niveles - Bad DOPO Cream");
        setSize(550, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fondoImagen != null) {
                    g.drawImage(fondoImagen, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(new Color(135, 206, 250));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        
        panelPrincipal.setLayout(null);
        panelPrincipal.setOpaque(false);
        
        JLabel titulo = new JLabel("CONFIGURAR NIVELES", SwingConstants.CENTER);
        titulo.setFont(new Font("Impact", Font.BOLD, 32));
        titulo.setForeground(Color.WHITE);
        titulo.setBounds(50, 20, 450, 40);
        panelPrincipal.add(titulo);
        
        lblNivel = new JLabel("NIVEL 1", SwingConstants.CENTER);
        lblNivel.setFont(new Font("Impact", Font.BOLD, 28));
        lblNivel.setForeground(new Color(255, 69, 0));
        lblNivel.setBounds(175, 70, 200, 35);
        panelPrincipal.add(lblNivel);
        
        int yInicial = 140;
        int espaciado = 75;
        
        agregarCampo(panelPrincipal, "Tipo de Mapa:", yInicial);
        cmbObstaculo = crearComboBox();
        cmbObstaculo.setModel(new DefaultComboBoxModel<TipoObstaculoMapa>(TipoObstaculoMapa.values()));
        cmbObstaculo.setBounds(200, yInicial, 290, 40);
        panelPrincipal.add(cmbObstaculo);
        
        agregarCampo(panelPrincipal, "Fruta 1:", yInicial + espaciado);
        cmbFruta1 = crearComboBox();
        cmbFruta1.setModel(new DefaultComboBoxModel<TipoFruta>(TipoFruta.values()));
        cmbFruta1.setBounds(200, yInicial + espaciado, 290, 40);
        panelPrincipal.add(cmbFruta1);
        
        agregarCampo(panelPrincipal, "Fruta 2:", yInicial + espaciado * 2);
        cmbFruta2 = crearComboBox();
        cmbFruta2.setModel(new DefaultComboBoxModel<TipoFruta>(TipoFruta.values()));
        cmbFruta2.setBounds(200, yInicial + espaciado * 2, 290, 40);
        panelPrincipal.add(cmbFruta2);
        
        agregarCampo(panelPrincipal, "Enemigo:", yInicial + espaciado * 3);
        cmbEnemigo = crearComboBox();
        cmbEnemigo.setModel(new DefaultComboBoxModel<TipoEnemigo>(TipoEnemigo.values()));
        cmbEnemigo.setBounds(200, yInicial + espaciado * 3, 290, 40);
        panelPrincipal.add(cmbEnemigo);
        
        btnAnterior = new JButton("ANTERIOR");
        btnAnterior.setFont(new Font("Arial", Font.BOLD, 14));
        btnAnterior.setBounds(70, 475, 150, 45);
        btnAnterior.setBackground(new Color(149, 165, 166));
        btnAnterior.setForeground(Color.WHITE);
        btnAnterior.setFocusPainted(false);
        btnAnterior.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btnAnterior.setEnabled(false);
        btnAnterior.addActionListener(new ListenerAnterior(this));
        panelPrincipal.add(btnAnterior);
        
        btnSiguiente = new JButton("SIGUIENTE");
        btnSiguiente.setFont(new Font("Arial", Font.BOLD, 14));
        btnSiguiente.setBounds(330, 475, 150, 45);
        btnSiguiente.setBackground(new Color(52, 152, 219));
        btnSiguiente.setForeground(Color.WHITE);
        btnSiguiente.setFocusPainted(false);
        btnSiguiente.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 2),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btnSiguiente.addActionListener(new ListenerSiguiente(this));
        panelPrincipal.add(btnSiguiente);
        
        btnJugar = new JButton("JUGAR");
        btnJugar.setFont(new Font("Impact", Font.BOLD, 24));
        btnJugar.setBounds(175, 530, 200, 50);
        btnJugar.setBackground(new Color(46, 204, 113));
        btnJugar.setForeground(Color.WHITE);
        btnJugar.setFocusPainted(false);
        btnJugar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 3),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        btnJugar.addActionListener(new ListenerJugar(this));
        panelPrincipal.add(btnJugar);
        
        add(panelPrincipal);
    }
    
    private JComboBox crearComboBox() {
        JComboBox combo = new JComboBox();
        combo.setFont(new Font("Arial", Font.BOLD, 15));
        combo.setBackground(Color.WHITE);
        combo.setForeground(new Color(44, 62, 80));
        combo.setBorder(BorderFactory.createLineBorder(new Color(52, 152, 219), 2));
        return combo;
    }
    
    private void agregarCampo(JPanel panel, String texto, int y) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Arial", Font.BOLD, 17));
        lbl.setForeground(new Color(44, 62, 80));
        lbl.setBounds(60, y, 130, 40);
        panel.add(lbl);
    }
    
    public void cambiarNivel(int direccion) {
        guardarConfiguracion();
        nivelActual = nivelActual + direccion;
        
        if (nivelActual < 1) {
            nivelActual = 1;
        }
        if (nivelActual > 3) {
            nivelActual = 3;
        }
        
        actualizarVista();
    }
    
    private void guardarConfiguracion() {
        int idx = nivelActual - 1;
        obstaculosSeleccionados[idx] = (TipoObstaculoMapa) cmbObstaculo.getSelectedItem();
        frutasSeleccionadas[idx][0] = (TipoFruta) cmbFruta1.getSelectedItem();
        frutasSeleccionadas[idx][1] = (TipoFruta) cmbFruta2.getSelectedItem();
        enemigosSeleccionados[idx] = (TipoEnemigo) cmbEnemigo.getSelectedItem();
    }
    
    private void actualizarVista() {
        int idx = nivelActual - 1;
        
        lblNivel.setText("NIVEL " + nivelActual);
        
        cmbObstaculo.setSelectedItem(obstaculosSeleccionados[idx]);
        cmbFruta1.setSelectedItem(frutasSeleccionadas[idx][0]);
        cmbFruta2.setSelectedItem(frutasSeleccionadas[idx][1]);
        cmbEnemigo.setSelectedItem(enemigosSeleccionados[idx]);
        
        if (nivelActual > 1) {
            btnAnterior.setEnabled(true);
        } else {
            btnAnterior.setEnabled(false);
        }
        
        if (nivelActual < 3) {
            btnSiguiente.setEnabled(true);
        } else {
            btnSiguiente.setEnabled(false);
        }
    }
    
    public void iniciarJuego() {
        guardarConfiguracion();
        
        try {
            GameEngine engine = new GameEngine(modalidad, saborHelado);
            
            for (int i = 0; i < 3; i++) {
                engine.setConfiguracionNivel(i, obstaculosSeleccionados[i], 
                    frutasSeleccionadas[i][0], frutasSeleccionadas[i][1], 
                    enemigosSeleccionados[i]);
            }
            
            engine.reiniciarJuego();
            dispose();
            
            VentanaJuego ventana = new VentanaJuego(modalidad, saborHelado);
            ventana.setVisible(true);
            
        } catch (GameException e) {
            JOptionPane.showMessageDialog(this, 
                "Error al iniciar el juego: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ==================== CLASES INTERNAS ====================
    
    private class ListenerAnterior implements ActionListener {
        private PantallaConfiguracionNiveles ventana;
        
        public ListenerAnterior(PantallaConfiguracionNiveles ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.cambiarNivel(-1);
        }
    }
    
    private class ListenerSiguiente implements ActionListener {
        private PantallaConfiguracionNiveles ventana;
        
        public ListenerSiguiente(PantallaConfiguracionNiveles ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.cambiarNivel(1);
        }
    }
    
    private class ListenerJugar implements ActionListener {
        private PantallaConfiguracionNiveles ventana;
        
        public ListenerJugar(PantallaConfiguracionNiveles ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.iniciarJuego();
        }
    }
}