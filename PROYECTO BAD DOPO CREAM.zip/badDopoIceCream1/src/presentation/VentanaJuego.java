package presentation;

import javax.swing.*;
import java.awt.*;
import logic.GameEngine;

/**
 * Ventana principal del juego que contiene el canvas y el HUD
 */
public class VentanaJuego extends JFrame {
    
    private CanvasJuego canvas;
    private HUD hud;
    private String modalidad;
    private String colorHelado;

    /**
     * Constructor con modalidad y color
     */
    public VentanaJuego(String modalidad, String colorHelado) {
        this.modalidad = modalidad;
        this.colorHelado = colorHelado;
        
        configurarVentana();
        inicializarComponentes();
    }

    /**
     * Constructor con GameEngine (para ConfiguracionInicial)
     */
    public VentanaJuego(GameEngine motor) {
        this.modalidad = motor.getModalidad();
        this.colorHelado = "Vainilla";
        
        configurarVentana();
        inicializarComponentes();
    }

    /**
     * Configura las propiedades de la ventana
     */
    private void configurarVentana() {
        setTitle("Bad DOPO Cream - Nivel 1");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());
    }

    /**
     * Inicializa los componentes (HUD y Canvas)
     */
    private void inicializarComponentes() {
        // Crear HUD
        hud = new HUD();
        add(hud, BorderLayout.NORTH);
        
        // Crear Canvas
        canvas = new CanvasJuego(modalidad, colorHelado, hud);
        add(canvas, BorderLayout.CENTER);
        
        // Ajustar tamaño
        pack();
        setLocationRelativeTo(null);
        
        // Dar foco al canvas para capturar teclas
        canvas.requestFocusInWindow();
    }

    /**
     * Obtiene el canvas del juego
     */
    public CanvasJuego getCanvas() {
        return canvas;
    }

    /**
     * Obtiene el HUD
     */
    public HUD getHUD() {
        return hud;
    }
}