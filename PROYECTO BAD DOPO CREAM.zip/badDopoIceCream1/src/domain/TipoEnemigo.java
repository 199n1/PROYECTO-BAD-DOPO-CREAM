package domain;

public enum TipoEnemigo {
    TROLL,
    MACETA,
    CALAMAR,
    NARVAL
}
