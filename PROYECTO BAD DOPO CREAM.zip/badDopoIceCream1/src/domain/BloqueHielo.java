package domain;

/**
 * Bloque de Hielo 
 */
public class BloqueHielo {
    private int x, y;
    private boolean permanente;
    private boolean activo;
    
    public BloqueHielo(int x, int y) {
        this.x = x;
        this.y = y;
        this.permanente = false;
        this.activo = true;
    }
    
    public BloqueHielo(int x, int y, boolean permanente) {
        this.x = x;
        this.y = y;
        this.permanente = permanente;
        this.activo = true;
    }
    
    public void destruir() {
        if (!permanente) {
            activo = false;
        }
    }
    
    public void reactivar() {
        activo = true;
    }
    
    public boolean isPermanente() { return permanente; }
    public boolean isActivo() { return activo; }
    public int getX() { return x; }
    public int getY() { return y; }
    public void setPermanente(boolean permanente) { this.permanente = permanente; }
}