package domain;

import java.util.Random;

/**
 * Troll: Se mueve en línea recta y cambia de dirección al chocar
 */
public class Troll extends Enemigo {
    private int contadorFrames;
    private Random random;

    public Troll(int x, int y, Mapa mapa) throws GameException {
        super(x, y, mapa);
        this.contadorFrames = 0;
        this.random = new Random();
        // Dirección inicial aleatoria
        String[] direcciones = {"arriba", "abajo", "izquierda", "derecha"};
        this.direccion = direcciones[random.nextInt(4)];
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        contadorFrames++;
        if (contadorFrames >= 30) { // Cada 0.5 segundos
            mover();
            contadorFrames = 0;
        }
    }

    @Override
    public void mover() {
        int nx = x;
        int ny = y;

        // Moverse en la dirección actual
        if (direccion.equals("derecha")) {
            nx++;
        } else if (direccion.equals("izquierda")) {
            nx--;
        } else if (direccion.equals("arriba")) {
            ny--;
        } else if (direccion.equals("abajo")) {
            ny++;
        }

        // Si puede moverse, avanzar
        if (posicionValida(nx, ny)) {
            x = nx;
            y = ny;
        } else {
            // Si choca, cambiar dirección aleatoriamente
            cambiarDireccionAleatoria();
        }
    }

    /**
     * Cambia a una dirección aleatoria diferente a la actual
     */
    private void cambiarDireccionAleatoria() {
        String[] direcciones = {"arriba", "abajo", "izquierda", "derecha"};
        String nuevaDireccion;
        
        do {
            nuevaDireccion = direcciones[random.nextInt(4)];
        } while (nuevaDireccion.equals(direccion));
        
        direccion = nuevaDireccion;
    }
}