package domain;

/**
 * Clase abstracta Enemigo 
 * - Los enemigos NO pueden entrar al iglú (posiciones 6-8, 6-8)
 */
public abstract class Enemigo {
    protected int x;
    protected int y;
    protected String direccion;
    protected boolean activo;
    protected Mapa mapa;

    public Enemigo(int x, int y, Mapa mapa) throws GameException {
        this.x = x;
        this.y = y;
        this.mapa = mapa;
        this.direccion = "abajo";
        this.activo = true;

        if (!mapa.dentroLimites(x, y)) {
            throw GameException.errorInicializacion("Posición inicial fuera de límites");
        }
    }

    public abstract void actualizar();
    public abstract void mover();

    /**
     * Verifica si una posición está dentro del iglú
     * El iglú ocupa las posiciones (6,6) a (8,8)
     */
    protected boolean esPosicionIglu(int x, int y) {
        return x >= 6 && x <= 8 && y >= 6 && y <= 8;
    }

    /**
     * Verifica si una posición es válida para el enemigo
     * Debe estar dentro de límites, libre de bloques y NO en el iglú
     */
    protected boolean posicionValida(int nx, int ny) {
        // Bloquear iglú
        if (esPosicionIglu(nx, ny)) {
            return false;
        }
        
        return mapa.dentroLimites(nx, ny) && mapa.posicionLibre(nx, ny);
    }

    public boolean isActivo() { return activo; }
    public int getX() { return x; }
    public int getY() { return y; }
    public String getDireccion() { return direccion; }
}