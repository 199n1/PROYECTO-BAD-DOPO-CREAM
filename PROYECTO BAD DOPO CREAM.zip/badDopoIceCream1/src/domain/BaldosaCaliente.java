package domain;

/**
 * Baldosa Caliente 
 * 
 */
public class BaldosaCaliente {
    private int x, y;
    
    public BaldosaCaliente(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    /**
     * Derrite bloques de hielo que estén sobre esta baldosa
     */
    public void derretirBloque(Mapa mapa) {
        BloqueHielo bloque = mapa.getBloque(x, y);
        if (bloque != null && bloque.isActivo()) {
            bloque.destruir();
            mapa.setBloque(x, y, null);
        }
    }
    
    public int getX() { return x; }
    public int getY() { return y; }
}