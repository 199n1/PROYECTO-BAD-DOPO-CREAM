package domain;

/**
 * Excepcion personalizada para errores del juego Bad Ice Cream
 * Maneja errores de mapa, movimiento, inicializacion y niveles
 */
public class GameException extends Exception {

    private String tipoError;

    /**
     * Constructor con mensaje
     */
    public GameException(String mensaje) {
        super(mensaje);
        this.tipoError = "GENERAL";
    }

    /**
     * Constructor con mensaje y tipo de error
     */
    public GameException(String mensaje, String tipoError) {
        super(mensaje);
        this.tipoError = tipoError;
    }

    /**
     * Constructor con mensaje y causa
     */
    public GameException(String mensaje, Throwable causa) {
        super(mensaje, causa);
        this.tipoError = "GENERAL";
    }

    /**
     * Obtiene el tipo de error
     */
    public String getTipoError() {
        return tipoError;
    }

    /**
     * Crea una excepcion de error de mapa
     */
    public static GameException errorMapa(String detalle) {
        return new GameException("Error en el mapa: " + detalle, "ERROR_MAPA");
    }

    /**
     * Crea una excepcion de error de movimiento
     */
    public static GameException errorMovimiento(String detalle) {
        return new GameException("Error de movimiento: " + detalle, "ERROR_MOVIMIENTO");
    }

    /**
     * Crea una excepcion de error de inicializacion
     */
    public static GameException errorInicializacion(String detalle) {
        return new GameException("Error de inicialización: " + detalle, "ERROR_INICIALIZACION");
    }

    /**
     * Crea una excepcion de error de nivel
     */
    public static GameException errorNivel(String detalle) {
        return new GameException("Error de nivel: " + detalle, "ERROR_NIVEL");
    }

    /**
     * Crea una excepcion de error de persistencia
     */
    public static GameException errorPersistencia(String detalle) {
        return new GameException("Error de persistencia: " + detalle, "ERROR_PERSISTENCIA");
    }

    /**
     * Crea una excepcion de error de colision
     */
    public static GameException errorColision(String detalle) {
        return new GameException("Error de colisión: " + detalle, "ERROR_COLISION");
    }

    @Override
    public String toString() {
        return tipoError + ": " + getMessage();
    }
}