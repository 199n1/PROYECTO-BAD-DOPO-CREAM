package domain;

/**
 * Clase abstracta que representa una fruta en el juego
 */
public abstract class Fruta {
    protected int x;
    protected int y;
    protected int puntos;
    protected boolean activa;

    public Fruta(int x, int y, int puntos) {
        this.x = x;
        this.y = y;
        this.puntos = puntos;
        this.activa = true;
    }

    public abstract String getTipo();
    public abstract void actualizar();

    public void recolectar() { activa = false; }
    public boolean isActiva() { return activa; }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getPuntos() { return puntos; }
}
