package domain;

/**
 * Clase Helado 
 * Representa al jugador en el juego
 */
public class Helado {
    private int x, y;
    private Mapa mapa;
    private String sabor;
    private boolean vivo;
    private String direccionActual;
    private int nivelActual;

    public Helado(int x, int y, Mapa mapa, String sabor) {
        this.x = x;
        this.y = y;
        this.mapa = mapa;
        this.sabor = sabor;
        this.vivo = true;
        this.direccionActual = "derecha";
        this.nivelActual = 1;
    }

    public void setMapa(Mapa mapa) {
        this.mapa = mapa;
        if (mapa != null) {
            this.nivelActual = mapa.getNumeroNivel();
        }
    }

    private boolean esPosicionIglu(int x, int y) {
        return x >= 6 && x <= 8 && y >= 6 && y <= 8;
    }

    public void mover(String direccion) {
        if (!vivo || mapa == null) return;
        
        this.direccionActual = direccion;
        int nuevoX = x;
        int nuevoY = y;

        if (direccion.equals("arriba")) {
            nuevoY = nuevoY - 1;
        } else if (direccion.equals("abajo")) {
            nuevoY = nuevoY + 1;
        } else if (direccion.equals("izquierda")) {
            nuevoX = nuevoX - 1;
        } else if (direccion.equals("derecha")) {
            nuevoX = nuevoX + 1;
        }

        // Bloquear iglú solo en nivel 1
        if (nivelActual == 1 && esPosicionIglu(nuevoX, nuevoY)) {
            return;
        }

        if (mapa.posicionLibre(nuevoX, nuevoY)) {
            x = nuevoX;
            y = nuevoY;
        }
    }

    /**
     * Crear bloques de hielo en línea
     */
    public void crearBloques() {
        if (!vivo || mapa == null) return;
        
        int bloqueX = x;
        int bloqueY = y;
        int deltaX = 0;
        int deltaY = 0;

        // Calcular dirección
        if (direccionActual.equals("arriba")) {
            deltaY = -1;
        } else if (direccionActual.equals("abajo")) {
            deltaY = 1;
        } else if (direccionActual.equals("izquierda")) {
            deltaX = -1;
        } else if (direccionActual.equals("derecha")) {
            deltaX = 1;
        }

        // Crear bloques hasta encontrar obstáculo
        boolean continuar = true;
        while (continuar) {
            bloqueX = bloqueX + deltaX;
            bloqueY = bloqueY + deltaY;
            
            // ¿Fuera del mapa?
            if (!mapa.dentroLimites(bloqueX, bloqueY)) {
                continuar = false;
                break;
            }
            
            // ¿Es el iglú? (solo nivel 1)
            if (nivelActual == 1 && esPosicionIglu(bloqueX, bloqueY)) {
                continuar = false;
                break;
            }
            
            // ¿Ya hay un bloque?
            BloqueHielo bloqueExistente = mapa.getBloque(bloqueX, bloqueY);
            if (bloqueExistente != null && bloqueExistente.isActivo()) {
                continuar = false;
                break;
            }
            
            // Crear bloque nuevo
            BloqueHielo nuevoBloque = new BloqueHielo(bloqueX, bloqueY, false);
            mapa.setBloque(bloqueX, bloqueY, nuevoBloque);
        }
    }

    /**
     * Romper bloques de hielo en línea
     * CORREGIDO según tu código
     */
    public void romperBloques() {
        if (!vivo || mapa == null) return;
        
        int bloqueX = x;
        int bloqueY = y;

        // Calcular dirección
        if (direccionActual.equals("arriba")) {
            bloqueY = bloqueY - 1;
        } else if (direccionActual.equals("abajo")) {
            bloqueY = bloqueY + 1;
        } else if (direccionActual.equals("izquierda")) {
            bloqueX = bloqueX - 1;
        } else if (direccionActual.equals("derecha")) {
            bloqueX = bloqueX + 1;
        }

        // Romper bloques uno por uno
        boolean continuar = true;
        while (continuar) {
            // ¿Fuera del mapa?
            if (!mapa.dentroLimites(bloqueX, bloqueY)) {
                continuar = false;
                break;
            }

            BloqueHielo bloque = mapa.getBloque(bloqueX, bloqueY);
            
            // ¿No hay bloque o está inactivo?
            if (bloque == null || !bloque.isActivo()) {
                continuar = false;
                break;
            }
            
            // ¿Es permanente?
            if (bloque.isPermanente()) {
                continuar = false;
                break;
            }

            // Destruir bloque
            bloque.destruir();
            mapa.setBloque(bloqueX, bloqueY, null);
            
            // Avanzar a siguiente posición
            if (direccionActual.equals("arriba")) {
                bloqueY = bloqueY - 1;
            } else if (direccionActual.equals("abajo")) {
                bloqueY = bloqueY + 1;
            } else if (direccionActual.equals("izquierda")) {
                bloqueX = bloqueX - 1;
            } else if (direccionActual.equals("derecha")) {
                bloqueX = bloqueX + 1;
            }
        }
    }

    public void morir() { 
        vivo = false; 
    }
    
    public void revivir() { 
        vivo = true; 
    }
    
    public boolean isVivo() { 
        return vivo; 
    }
    
    public int getX() { 
        return x; 
    }
    
    public int getY() { 
        return y; 
    }
    
    public String getSabor() { 
        return sabor; 
    }
    
    public String getDireccion() { 
        return direccionActual; 
    }
}